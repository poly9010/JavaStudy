import java.util.Scanner;


public class homework7 {
    public static class Fraction{
        int numerator;//분자필드
        int denominator;//분모필드


        public Fraction(){ //분자와 분모를 1로 지정하는 생성자
            this.numerator = 1;
            this.denominator = 1;
        }
        public Fraction(int d){//분자는 1로 지정, 분모는 d로 지정하는 생성자
            this.numerator = 1;
            this.denominator = d;
        }
        public Fraction(int n, int d){//분자는 n,분모는 d로 지정하는 생성자
            this.numerator = n;
            this.denominator = d;
        }

        public void addFraction(Fraction addFraction_1,Fraction addFraction_2){//분수 덧셈 메소드
            int a,b,c,d;
            a = addFraction_1.numerator;
            b = addFraction_1.denominator;
            c = addFraction_2.numerator;
            d = addFraction_2.denominator;
            this.numerator  = (a*d)+(c*b);
            this.denominator = b*d;
            int n = redFraction(this.numerator,this.denominator);//redFraction 호출하여 n에 최대공약수 지정
            this.numerator = (this.numerator/n); //최대공약수로 나눈 기약분수의 분자
            this.denominator = (this.denominator/n);//최대공약수로 나눈 기약분수의 분모
        }
        public void subFraction(Fraction subFraction_1,Fraction subFraction_2){//뺼셈
            int a,b,c,d;
            a = subFraction_1.numerator;
            b = subFraction_1.denominator;
            c = subFraction_2.numerator;
            d = subFraction_2.denominator;
            this.numerator = (a*d)-(c*b);
            this.denominator = b*d;
            int n = redFraction(this.numerator,this.denominator);//redFraction 호출하여 n에 최대공약수 지정
            this.numerator = (this.numerator/n);
            this.denominator = (this.denominator/n);
        }
        public void mulFraction(Fraction mulFraction_1,Fraction mulFraction_2){//곱셈
            int a,b,c,d;
            a = mulFraction_1.numerator;
            b = mulFraction_1.denominator;
            c = mulFraction_2.numerator;
            d = mulFraction_2.denominator;
            this.numerator = a*c;
            this.denominator = b*d;
            int n = redFraction(this.numerator,this.denominator);//redFraction 호출하여 n에 최대공약수 지정
            this.numerator = (this.numerator/n);
            this.denominator = (this.denominator/n);
        }


        public void divFraction(Fraction divFraction_1,Fraction divFraction_2){//나눗셈
            int a,b,c,d;
            a = divFraction_1.numerator;
            b = divFraction_1.denominator;
            c = divFraction_2.numerator;
            d = divFraction_2.denominator;
            this.numerator = a*d;
            this.denominator = b*c;
            int n = redFraction(this.numerator,this.denominator);//redFraction 호출하여 n에 최대공약수 지정
            this.numerator = (this.numerator/n);
            this.denominator = (this.denominator/n);
        }

        public int redFraction(int n,int d){//약분 (n = numerator, d = dominator)
            int tmp=-1;//tmp임시 지정
            while(tmp!=0){//유클리드 호제법 사용(최대공약수 구하기)
                tmp = n % d;
                n = d;
                d = tmp;
            }
            if(n==1){return 1;}//두 수가 서로소일시 1반환
            else{return n;}//최대공약수 반환
        }

        public void printFraction(Fraction f1,Fraction f2){//출력메소드
            addFraction(f1, f2);//덧셈메소드 호출
            System.out.println(f1.numerator+"/"+f1.denominator+" + "+ f2.numerator+"/"+f2.denominator+" = "+this.numerator+"/"+this.denominator);
            subFraction(f1,f2);//뺄셈메소드출 호출
            System.out.println(f1.numerator+"/"+f1.denominator+" - "+ f2.numerator+"/"+f2.denominator+" = "+this.numerator+"/"+this.denominator);
            mulFraction(f1,f2);//곱셈메소드 호출
            System.out.println(f1.numerator+"/"+f1.denominator+" * "+ f2.numerator+"/"+f2.denominator+" = "+this.numerator+"/"+this.denominator);
            divFraction(f1,f2);//나눗셈메소드 호출
            System.out.println(f1.numerator+"/"+f1.denominator+" / "+ f2.numerator+"/"+f2.denominator+" = "+this.numerator+"/"+this.denominator);
        }
    }

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int numerator_1,numerator_2,denominator_1,denominator_2;

        System.out.print("분수 1 입력(분자 분모): ");
        numerator_1 = scanner.nextInt();
        denominator_1 = scanner.nextInt();

        System.out.print("분수 2 입력(분자 분모): ");
        numerator_2 = scanner.nextInt();
        denominator_2 = scanner.nextInt();

        Fraction Fraction_1 = new Fraction(numerator_1,denominator_1);//분수1을 저장하는 객체 생성
        Fraction Fraction_2 = new Fraction(numerator_2,denominator_2);//분수2를 저장하는 객체 생성

        Fraction result = new Fraction();
        result.printFraction(Fraction_1,Fraction_2);//출력결과메소드 호출
        scanner.close();












    }

}